from genericpath import exists
import connexion
from connexion import NoContent
from sqlalchemy import create_engine, desc
from sqlalchemy.orm import sessionmaker
import datetime
from base import Base
import requests
import yaml
import logging
import logging.config
import json

from pathlib import Path
from apscheduler.schedulers.background import BackgroundScheduler
from stats import Stats
import ast  

with open('app_conf.yml', 'r') as f:
    app_config = yaml.safe_load(f.read())

with open('log_conf.yml', 'r') as f:
    log_config = yaml.safe_load(f.read())
    logging.config.dictConfig(log_config)

logger = logging.getLogger('basicLogger')


# DB_ENGINE = create_engine("sqlite:///stats.sqlite")
DB_ENGINE = create_engine("sqlite:///%s" %app_config["datastore"]["filename"])
Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)

def get_stats():
    logger.info('Request has been started')
    session = DB_SESSION()
    results = session.query(Stats).order_by(Stats.last_updated.desc())
    lst =[]
    for i in results:
      dict =Stats.to_dict(i)
    lst.append(dict)


def populate_stats():
    """ Periodically update stats """
    logger.info('Period processing has been started')
    session = DB_SESSION()
    results = session.query(Stats).order_by(Stats.last_updated.desc())
    last = str(results[0].last_updated)
    a,b = last.split(" ")
    print(a)
    c = a.replace("-","/")
    print(c)
    print(b)
    # print(results[0].num_phlevel_reading)
    session.close()
    headers = {"content-type": "application/json"}
    
    response_ph_level = requests.get(app_config["phlevel"]['url'], headers=headers)
    response_chlorine_level = requests.get(app_config["chlorinelevel"]['url'], headers=headers)
    list = response_ph_level.json()
    list1 =response_chlorine_level.json()
    
    logger.info(f"Number of events received {len(list)}")
    if response_ph_level.status_code != 200: 
        logger.error(f"Status code received {response_ph_level.status_code}")

    new_event = list[-1]
    if len(list) > results[0].num_phlevel_reading :
        logger.debug(f"New event added with trace id {new_event['trace_id']}")
    else: 
      pass
        
    logger.info('Started Periodic Processing')
    num_phlevel_reading = len(list)
    max_phlevel_reading = 0
    max_water_level = 0
    max_chlorine_level = 0
    num_chlorine_level = len(list1)
    last_updated = datetime.datetime.now().strftime("%m/%d/%Y %H:%M:%S.%f")

    for i in list:
        if i["phlevel"] >  max_phlevel_reading:
            max_phlevel_reading = i["phlevel"] 
        if i["waterlevel"] > max_water_level:
            max_water_level = i["waterlevel"] 

    for i in list1:
      if i["chlorinelevel"] > max_chlorine_level:
        max_chlorine_level = i["chlorinelevel"]
      if i["waterlevel"] > max_water_level:
        max_water_level = i["waterlevel"] 

    
    session = DB_SESSION()
    stats = Stats(num_phlevel_reading,
        max_phlevel_reading,
        max_water_level,
        max_chlorine_level,
        num_chlorine_level,
        datetime.datetime.strptime(last_updated,
        "%m/%d/%Y %H:%M:%S.%f"))

    session.add(stats)

    session.commit()
    session.close()

def init_scheduler():
    sched = BackgroundScheduler(daemon=True)
    sched.add_job(populate_stats, 'interval', seconds=app_config['scheduler']['period_sec'])
    sched.start()

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yaml", strict_validation=True, validate_responses=True)

if __name__ == "__main__":
    init_scheduler()
    get_stats()
    app.run(port=8100, use_reloader=False)  



